export interface User {
    id: number;
    username: string;
    //passwd: string;
    apikey: string;
}
