import { ArticleFilterPipe } from './article-filter-pipe';

describe('ArticleFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ArticleFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
